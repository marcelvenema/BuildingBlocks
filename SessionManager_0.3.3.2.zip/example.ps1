param ([string] $message = "")
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null
[System.Windows.Forms.MessageBox]::Show("This is an example for a SessionManager action. Event : "+$message+"`nSee http://www.marcelvenema.com/sessionmanager for more information." , "MarcelVenema.com SessionManager")
